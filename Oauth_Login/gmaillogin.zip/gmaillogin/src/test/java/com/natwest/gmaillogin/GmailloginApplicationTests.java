package com.natwest.gmaillogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmailloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
